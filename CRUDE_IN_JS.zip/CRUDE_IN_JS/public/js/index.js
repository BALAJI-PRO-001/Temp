import UserInterface from "./modules/UserInterface.js";
import CommonFunction from "./modules/CommonFunction.js";
import User from "./modules/User.js";

const user = new User();
const ui = new UserInterface();
const commonFunction = new CommonFunction();

const container = document.getElementById("container");
let userRecordsTable = null;


/* Load user records from localstorage */
if (user.getUsersCount() == 0) {
  const messageContainer = document.getElementById("message-container");
  messageContainer.style.display = "block";
} else {
  const users = user.getUsers();
  const columnNames = ["Id", "Name", "Email", "Update", "Delete"];
  const options = [
    `<button class="update-btn">Update</button>`, 
    `<button class="delete-btn">Delete</button>`
  ];

  userRecordsTable = ui.createTable(columnNames, users, options);
  container.appendChild(userRecordsTable);
}


const popupMenu = document.getElementById("popup-menu");
var previousEvent = null;

// Get all delete buttons from user records table if tabel is exist
if (userRecordsTable != null) {
  const deleteButtons = userRecordsTable.querySelectorAll(".delete-btn");
  for (let button of deleteButtons) {
    button.addEventListener("click", (event) => {
      popupMenu.style.display = "block";
      previousEvent = event;
    });
  }
}



// Handel delete user records based on email and password
popupMenu.querySelector(".confirm-btn").addEventListener("click",  (event) => {
  const inputElement = commonFunction.getSibling(event.target, "input");
  const errorElement = inputElement.nextElementSibling;
  const id = Number(previousEvent.target.parentElement.parentElement.children[0].innerText);
  const email = previousEvent.target.parentElement.parentElement.children[2].innerText;
  const signinInformation = user.signin(email, inputElement.value.trim());
  
  if (!signinInformation.status) {
    ui.setBorder(inputElement, ui.BORDER_1PX_RED);
    ui.setMessage(errorElement, "Incorrect password. Please try again");
    setTimeout(() => {
      ui.setBorder(inputElement, "1px solid black");
      ui.setMessage(errorElement, "");
    }, 2000);
  } else {
    user.delete(id);
    previousEvent.target.parentElement.parentElement.remove();
    popupMenu.style.display = "none";
  }
});


popupMenu.querySelector(".cancel-btn").addEventListener("click", (event) => {
  event.target.parentElement.parentElement.style.display = "none";
});





/* Get all update buttons if userRecordsTable is exist */
if (userRecordsTable != null) {
  const updateButtons = userRecordsTable.querySelectorAll(".update-btn");
  for (let button of updateButtons) {
    button.addEventListener("click", (event) => {
      previousEvent = event;
      popupEditMenu.style.display = "block";

      // Load username and email into inputFields
      const inputElements = popupEditMenu.querySelectorAll("input");
      const name = button.parentElement.parentElement.children[1].innerText;
      const email = button.parentElement.parentElement.children[2].innerText;

      inputElements[0].value = name;
      inputElements[1].value = email;
    });
  }
}


/* Handle update menu */
const popupEditMenu = document.getElementById("popup-edit-menu");


popupEditMenu.querySelector(".cancel-btn").addEventListener("click", (event) => {
  event.target.parentElement.parentElement.style.display = "none";
});


// Handle update event 
popupEditMenu.querySelector(".update-btn").addEventListener("click", (event) => {
  const inputElements = event.target.parentElement.querySelectorAll("input");
  const email = inputElements[1].value.trim();
  const password = inputElements[2].value.trim();

  const signinInformation = user.signin(email, password);
  if (!signinInformation.password) {
    const errorElement = commonFunction.getSibling(inputElements[2], "p");
    ui.setBorder(inputElements[2], ui.BORDER_1PX_RED);
    ui.setMessage(errorElement, "Invalid password. Please try again . . . .");
  }
});