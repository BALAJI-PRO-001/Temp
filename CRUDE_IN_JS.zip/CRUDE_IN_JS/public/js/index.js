import UserInterface from "./modules/UserInterface.js";
import User from "./modules/User.js";

const user = new User();
const ui = new UserInterface();

const container = document.getElementById("container");
let userRecordsTable = null;

/* Load user records from localstorage */
if (user.getUsersCount() == 0) {
  const h1 = document.createElement("h1");
  h1.setAttribute("class", "error-message");
  h1.innerText = "Message: No user records exist . . . .";
  container.appendChild(h1);
} else {
  const users = user.getUsers();
  const columnNames = ["Id", "Name", "Email", "Update", "Delete"];
  const options = [
    `<button class="edit-btn">Update</button>`, 
    `<button class="delete-btn">Delete</button>`
  ];

  userRecordsTable = ui.createTable(columnNames, users, options);
  container.appendChild(userRecordsTable);
}


const popupMenu = document.getElementById("popup-menu");
const deleteButtons = userRecordsTable.querySelectorAll(".delete-btn");

for (let button of deleteButtons) {
  button.addEventListener("click", () => {
    popupMenu.style.display = "block";
  });
}


popupMenu.querySelector(".cancel-btn").addEventListener("click", (event) => {
  event.target.parentElement.parentElement.style.display = "none";
});