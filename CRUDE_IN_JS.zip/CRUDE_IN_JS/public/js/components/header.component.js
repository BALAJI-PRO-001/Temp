
const Header = ` 
  <header>
    <h1>User Management System</h1>
    <nav class="navbar">
      <a href="../pages/index.html" class="active">Home</a>
      <a href="../forms/signup.html">Sign up</a> 
      <a href="../forms/signin.html">Sign in</a> 
    </nav>
  </header>
`;

export default Header;